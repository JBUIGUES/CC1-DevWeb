"use strict";

// Sélectionnez les élément <input> avec l'id "id"
const $startBtn = document.getElementById("start-btn");
const $guessBtn = document.getElementById("guess-btn");
const $cowBtn = document.getElementById("cow-btn");
const $output = document.getElementById("output");
const $numUsr = document.getElementById("num-usr");
const $maxUsr = document.getElementById("max-usr");
const $removeCowsBtn = document.getElementById("remove-cows-btn");


//déclare les variables utilisées
let secretNumber = 0;
let nbGuesses = 0;
let maxGuesses = 0;


function launchGame(_evt) {
    // Génère un nombre secret number aléatoire entre 1 et le nombre maximum saisi par l'utilisateur
    secretNumber = Math.floor(Math.random() * parseInt($maxUsr.value)) + 1;

    // Calcule le nombre limite de coups
    maxGuesses = Math.floor(Math.random() * parseInt($maxUsr.value)) + 2;

    // Réinitialiser le nombre d'essais
    nbGuesses = 0;

    // Activer le bouton "Vérifier"
    $guessBtn.disabled = false;

    // Effacer le contenu de l'élément de sortie
    $output.textContent = "Nouveau jeu démarré. Essayez de deviner le nombre !";

    // Activer la zone de saisie de l'utilisateur
    $numUsr.disabled = false;

    // Mettre le focus sur la zone de saisie de l'utilisateur
    $numUsr.focus();
}
$startBtn.addEventListener("click", launchGame);


function checkGuess() {
    //rajoute +1 a la variable à chaque itération
    nbGuesses++;
    //créé une variable qui récupère sous forme d'int la string de la valeur entrée
    const userGuess = parseInt($numUsr.value);
    //vérifie si le joueur à le droit de tenter un essai
    if (nbGuesses < maxGuesses) {
        //cas où le joueur a bon
        if (userGuess === secretNumber) {
            $output.textContent = `Bravo ! Vous avez trouvé le nombre secret ${secretNumber} en ${nbGuesses} essais.`;
            //désactive le bouton
            $guessBtn.disabled = true;
            //désactive la zone de saisie
            $numUsr.disabled = true;
        //cas où le joueur a donné un nombre trop bas
        } else if (userGuess < secretNumber) {
            $output.textContent = `Trop bas. Essayez encore (${maxGuesses - nbGuesses - 1} essais restants)`;
        //cas où le joueur a donné un nombre trop élevé
        } else {
            $output.textContent = `Trop élevé. Essayez encore (${maxGuesses - nbGuesses - 1} essais restants)`;
        }
    }
    //cas où le joueur à dépassé le nombre d'essais défini
    if(nbGuesses >= maxGuesses -1) {
        $output.textContent = `Désolé, vous avez épuisé tous vos essais. Le nombre secret était ${secretNumber}.`;
        //désactive le bouton
        $guessBtn.disabled = true;
        //désactive la zone de saisie
        $numUsr.disabled = true;
    }
}
$guessBtn.addEventListener("click", checkGuess);


// Ajoute un gestionnaire d'événements "keydown" à l'élément <input>
$numUsr.addEventListener("keydown", function (event) {
    // Vérifie si la touche appuyée est la touche Entrée (code de touche 13)
    if (event.keyCode === 13) {
        // Vérifie si le bouton "Vérifier" est activé
        if (!$guessBtn.disabled) {
            // Appel la fonction de vérification (checkGuess) lorsque la touche Entrée est enfoncée
            checkGuess();
        }
        // Empêche la touche Entrée de provoquer un événement de formulaire
        event.preventDefault();
    }
});


function addCow(evt) {
    // Créé une image de vache avec sa source et l'ajoute a classList
    const cowImage = document.createElement("img");
    cowImage.src = "https://upload.wikimedia.org/wikipedia/commons/3/30/Cowicon.svg";
    cowImage.classList.add("cow");
  
    // Positionne l'image de vache à l'endroit du clic de la souris
    cowImage.style.position = "absolute";
    cowImage.style.left = evt.clientX + "px";
    cowImage.style.top = evt.clientY + "px";
  
    // Fait tourner aléatoirement l'image de vache
    const rotationDegrees = Math.random() * 360;
    cowImage.style.transform = `rotate(${rotationDegrees}deg)`;
  
    // Ajoute l'image de vache à la fin de la page
    document.body.appendChild(cowImage);
}


//si activé, appelle addCow, ne fais rien, sinon avec onmousedown
function toggleCow(_evt) {
    if (document.onmousedown instanceof Function) {
        document.onmousedown = null;
    } else {
        document.onmousedown = addCow;
    }
}
$cowBtn.addEventListener("click", toggleCow);


function removeCows() {
    // Sélectionne toutes les images de classe "cow"
    const cowImages = document.querySelectorAll(".cow");
  
    // Parcoure les images de vaches et les retires de la page
    cowImages.forEach((cowImage) => {
        cowImage.remove();
    });
}
$removeCowsBtn.addEventListener("click", removeCows);